﻿
namespace CodeGenerator.Common
{
    /// <summary>
    /// The class that stores the list of column information of a sql table.
    /// </summary>
    public class ColumnInformationCollection : System.Collections.Generic.List<ColumnInformation>
    {
        /// <summary>
        /// The constructor that creates a column information collection object.
        /// </summary>
        public ColumnInformationCollection()
        {
        }
    }
}
