﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGenerator.Common
{
    public class ServerBox
    {
        public string ServerInstance { get; set; }
        public string ServerUsername { get; set; }
        public string ServerPassword { get; set; }
        public bool IsValuesEmpty
        {
            get { return string.IsNullOrEmpty(ServerInstance) || string.IsNullOrEmpty(ServerUsername) || string.IsNullOrEmpty(ServerPassword); }
        }
        public bool IsWindowsAuth { get; set; }
    }
}
