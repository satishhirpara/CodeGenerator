﻿
namespace CodeGenerator.Common
{
    /// <summary>
    /// The enum that has the class languages.
    /// </summary>
    public enum ClassLanguages
    {
        /// <summary>
        /// Represents CSharp Language.
        /// </summary>
        CSharp,
        /// <summary>
        /// Represents Visual Basic Language.
        /// </summary>
        VisualBasic
    };
}
