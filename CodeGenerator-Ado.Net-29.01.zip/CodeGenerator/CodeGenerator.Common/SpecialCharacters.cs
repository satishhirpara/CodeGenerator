﻿
namespace CodeGenerator.Common
{
    /// <summary>
    /// The class that contains the special characters.
    /// </summary>
    public class SpecialCharacters
    {
        /// <summary>
        /// Represents the left curly bracket.
        /// </summary>
        public const string LEFT_CURLY_BRACKET = "{";
        /// <summary>
        /// Represents the right curly bracket.
        /// </summary>
        public const string RIGHT_CURLY_BRACKET = "}";
        /// <summary>
        /// Represents the left parenthesis.
        /// </summary>
        public const string LEFT_PARENTHESIS = "(";
        /// <summary>
        /// Represents the right parenthesis.
        /// </summary>
        public const string RIGHT_PARENTHESIS = ")";
        /// <summary>
        /// Represents the left bracket.
        /// </summary>
        public const string LEFT_BRACKET = "[";
        /// <summary>
        /// Represents the right bracket.
        /// </summary>
        public const string RIGHT_BRACKET = "]";
        /// <summary>
        /// Represents the horizontal tab.
        /// </summary>
        public const string HORIZONTAL_TAB = "\t";
        /// <summary>
        /// Represents the semi colon.
        /// </summary>
        public const string SEMI_COLON = ";";
    }
}
