﻿
namespace CodeGenerator.Common
{
    /// <summary>
    /// The class that contains the csharp keywords.
    /// </summary>
    public class CSKeywords
    {
        /// <summary>
        /// Represents the keyword 'private'.
        /// </summary>
        public const string PRIVATE = "private";
        /// <summary>
        /// Represents the keyword 'public'.
        /// </summary>
        public const string PUBLIC  = "public";
        /// <summary>
        /// Represents the keyword 'string'.
        /// </summary>
        public const string STRING =  "string";
        /// <summary>
        /// Represents the keyword 'int'.
        /// </summary>
        public const string INT = "int";
        /// <summary>
        /// Represents the keyword 'float'.
        /// </summary>
        public const string FLOAT = "float";
        /// <summary>
        /// Represents the keyword 'double'.
        /// </summary>
        public const string DOUBLE = "double";
        /// <summary>
        /// Represents the keyword 'DateTime'.
        /// </summary>
        public const string DATETIME = "DateTime";
        /// <summary>
        /// Represents the keyword 'object'.
        /// </summary>
        public const string OBJECT = "object";
        /// <summary>
        /// Represents the keyword 'class'.
        /// </summary>
        public const string CLASS = "class";
        /// <summary>
        /// Respresents the keyword 'namespace'.
        /// </summary>
        public const string NAMESPACE = "namespace";
        /// <summary>
        /// Represents the keyword 'using'.
        /// </summary>
        public const string USING = "using";
        /// <summary>
        /// Represents the keyword 'get'.
        /// </summary>
        public const string GET = "get";
        /// <summary>
        /// Represents the keyword 'set'.
        /// </summary>
        public const string SET = "set";
        /// <summary>
        /// Represents the keyword 'new'.
        /// </summary>
        public const string NEW = "new";
        /// <summary>
        /// Represents the keyword 'return'.
        /// </summary>
        public const string RETURN = "return";
    }
}
