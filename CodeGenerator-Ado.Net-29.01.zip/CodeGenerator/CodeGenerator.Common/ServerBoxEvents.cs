﻿using System;
using System.Windows.Forms;

namespace CodeGenerator.Common
{
    /// <summary>
    /// The class that handles the event of the server box.
    /// </summary>
    public class ServerBoxEvents
    {
        private ServerBox serverBox;

        /// <summary>
        /// The constructor that initializes the server box event class.
        /// </summary>
        /// <param name="serverBox">The server box class.</param>
        public ServerBoxEvents(ServerBox serverBox)
        {
            this.serverBox = serverBox;
        }

        /// <summary>
        /// The method that connects to the database.
        /// </summary>
        /// <returns>Returns whether database is connected or not.</returns>
        public bool Connect()
        {
            bool connectionResult = false;
            try
            {
                CommonFunctions.SqlServerEventHandler = new SqlServerHandler(serverBox.ServerInstance, serverBox.ServerUsername,
                    serverBox.ServerPassword, serverBox.IsWindowsAuth);
                connectionResult = CommonFunctions.SqlServerEventHandler.Connect();
            }
            catch (Exception ex)
            {
                CommonFunctions.ShowMessageBox("Error Occured!\n" + ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return connectionResult;
        }
    }
}
