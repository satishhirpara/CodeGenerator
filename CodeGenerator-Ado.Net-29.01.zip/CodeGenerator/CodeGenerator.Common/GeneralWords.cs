﻿
namespace CodeGenerator.Common
{
    /// <summary>
    /// The class that contains general words that are required for the classes.
    /// </summary>
    public class GeneralWords
    {
        /// <summary>
        /// Represents the cs file extension.
        /// </summary>
        public const string CS_FILE_EXTENSION = ".cs";
        /// <summary>
        /// Represents the vb file extension.
        /// </summary>
        public const string VB_FILE_EXTENSION  = ".vb";
        /// <summary>
        /// Represents the suffix used for business logic layer class.
        /// </summary>
        public const string BLL_CLASS_SUFFIX = "BLL";
        /// <summary>
        /// Represents the suffix used for data access layer class.
        /// </summary>
        public const string DAL_CLASS_SUFFIX = "DAL";
        /// <summary>
        /// Represents the default namespace for value object class.
        /// </summary>
        public const string VO_CLASS_NAMESPACE = "VO";
        /// <summary>
        /// Represents the default namespace for business logic layer class.
        /// </summary>
        public const string BLL_CLASS_NAMESPACE = "BLL";
        /// <summary>
        /// Represents the default namespace for data access layer class.
        /// </summary>
        public const string DAL_CLASS_NAMESPACE = "DAL";
    }
}
