﻿
namespace CodeGenerator.Common
{
    /// <summary>
    /// The class that contains the visual basic keywords.
    /// </summary>
    public class VBKeywords
    {
        /// <summary>
        /// Represents the keyword 'Private'.
        /// </summary>
        public const string PRIVATE = "Private";
        /// <summary>
        /// Represents the keyword 'Public'.
        /// </summary>
        public const string PUBLIC  = "Public";
        /// <summary>
        /// Represents the keyword 'String'.
        /// </summary>
        public const string STRING =  "String";
        /// <summary>
        /// Represents the keyword 'Integer'.
        /// </summary>
        public const string INTEGER = "Integer";
        /// <summary>
        /// Represents the keyword 'Single'.
        /// </summary>
        public const string SINGLE = "Single";
        /// <summary>
        /// Represents the keyword 'Double'.
        /// </summary>
        public const string DOUBLE = "Double";
        /// <summary>
        /// Represents the keyword 'DateTime'.
        /// </summary>
        public const string DATETIME = "DateTime";
        /// <summary>
        /// Represents the keyword 'Object'.
        /// </summary>
        public const string OBJECT = "Object";
        /// <summary>
        /// Represents the keyword 'Class'.
        /// </summary>
        public const string CLASS = "Class";
        /// <summary>
        /// Represents the keyword 'Namespace'.
        /// </summary>
        public const string NAMESPACE = "Namespace";
        /// <summary>
        /// Represents the keyword 'Imports'.
        /// </summary>
        public const string IMPORTS = "Imports";
        /// <summary>
        /// Represents the keyword 'Get'.
        /// </summary>
        public const string GET = "Get";
        /// <summary>
        /// Represents the keyword 'Set'.
        /// </summary>
        public const string SET = "Set";
        /// <summary>
        /// Represents the keyword 'Property'.
        /// </summary>
        public const string PROPERTY = "Property";
        /// <summary>
        /// Represents the keyword 'End'.
        /// </summary>
        public const string END = "End";
        /// <summary>
        /// Represents the keyword 'As'.
        /// </summary>
        public const string AS = "As";
        /// <summary>
        /// Represents the keyword ' Byval'.
        /// </summary>
        public const string BYVAL = "ByVal";
        /// <summary>
        /// Represents the keyword 'Sub'.
        /// </summary>
        public const string SUB = "Sub";
        /// <summary>
        /// Represents the keyword 'New'.
        /// </summary>
        public const string NEW = "New";
        /// <summary>
        /// Represents the keyword 'MyBase'.
        /// </summary>
        public const string MYBASE = "MyBase";
        /// <summary>
        /// Represents the keyword 'Return'.
        /// </summary>
        public const string RETURN = "Return";
    }
}
