﻿
namespace CodeGenerator.Common
{
    /// <summary>
    /// The class that contains the column information of a sql table.
    /// </summary>
    public class ColumnInformation
    {
        /// <summary>
        /// The type of the column of the sql table for cs.
        /// </summary>
        public string CSType { get; set; }

        /// <summary>
        /// The type of the column of the sql table for vb.
        /// </summary>
        public string VBType { get; set; }

        /// <summary>
        /// The name of sql column of the sql table.
        /// </summary>
        public string SqlName { get; set; }

        /// <summary>
        /// The name of the column name of the sql table.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// The constructor that initalizes the column information class.
        /// </summary>
        /// <param name="CSType">The type of the column of the sql table for cs.</param>
        /// <param name="VBType">The type of the column of the sql table for vb.</param>
        /// <param name="SqlName">The name of sql column of the sql table.</param>
        /// <param name="Name">The name of the column name of the sql table.</param>
        public ColumnInformation(string CSType, string VBType, string SqlName, string Name)
        {
            this.CSType = CSType;
            this.VBType = VBType;
            this.SqlName = SqlName;
            this.Name = Name;
        }
    }
}
