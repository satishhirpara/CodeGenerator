﻿
namespace CodeGenerator.Common
{
    /// <summary>
    /// The class that stores the values that are entered in ui.
    /// </summary>
    public class UIEntryStore
    {
        /// <summary>
        /// The instance of the server.
        /// </summary>
        public string ServerInstance { get; set; }
        /// <summary>
        /// The username of the server.
        /// </summary>
        public string ServerUsername { get; set; }
        /// <summary>
        /// The password of the server.
        /// </summary>
        public string ServerPassword { get; set; }
        /// <summary>
        /// The name of the database.
        /// </summary>
        public string DatabaseName { get; set; }
        /// <summary>
        /// The name of the table.
        /// </summary>
        public string TableName { get; set; }
        /// <summary>
        /// The primary key of the table.
        /// </summary>
        public string PrimaryKey { get; set; }
        /// <summary>
        /// The list of columns of the table.
        /// </summary>
        public ColumnInformationCollection ColumnsInformation { get; set; }
        /// <summary>
        /// The location where the class files are created.
        /// </summary>
        public string FileLocation { get; set; }
        /// <summary>
        /// The namespace of the value object class.
        /// </summary>
        public string VONamespace { get; set; }
        /// <summary>
        /// The parent directory of the value object class.
        /// </summary>
        public string[] VOParentDirectories { get; set; }
        /// <summary>
        /// The name of the value object class.
        /// </summary>
        public string VOClassName { get; set; }
        /// <summary>
        /// The namespace of the business logic layer class.
        /// </summary>
        public string BLLNamespace { get; set; }
        /// <summary>
        /// The parent directory of the business logic layer class.
        /// </summary>
        public string[] BLLParentDirectories { get; set; }
        /// <summary>
        /// The name of the business logic layer class.
        /// </summary>
        public string BLLClassName { get; set; }
        /// <summary>
        /// The namespace of the data access layer class.
        /// </summary>
        public string DALNamespace { get; set; }
        /// <summary>
        /// The parent directory of the data access layer class.
        /// </summary>
        public string[] DALParentDirectories { get; set; }
        /// <summary>
        /// The name of the data access layer class.
        /// </summary>
        public string DALClassName { get; set; }
        /// <summary>
        /// The class file language.
        /// </summary>
        public ClassLanguages ClassFileLanguage { get; set; }
    }
}
