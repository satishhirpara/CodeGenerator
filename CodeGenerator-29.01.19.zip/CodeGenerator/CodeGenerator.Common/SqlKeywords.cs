﻿
namespace CodeGenerator.Common
{
    /// <summary>
    /// The class that contains the sql keywords.
    /// </summary>
    public class SqlKeywords
    {
        /// <summary>
        /// Represents the keyword 'insert'.
        /// </summary>
        public const string INSERT = "INSERT";
        /// <summary>
        /// Represents the keyword 'update' 
        /// </summary>
        public const string UPDATE = "UPDATE";
        /// <summary>
        /// Represents the keyword 'delete'.
        /// </summary>
        public const string DELETE = "DELETE";
        /// <summary>
        /// Represents the keyword 'into'.
        /// </summary>
        public const string INTO = "INTO";
        /// <summary>
        /// Represents the keyword 'set'.
        /// </summary>
        public const string SET = "SET";
        /// <summary>
        /// Represents the keyword 'values'.
        /// </summary>
        public const string VALUES = "VALUES";
        /// <summary>
        /// Represents the keyword 'select'.
        /// </summary>
        public const string SELECT = "SELECT";
        /// <summary>
        /// Represents the keyword 'from'.
        /// </summary>
        public const string FROM = "FROM";
        /// <summary>
        /// Represents the keyword 'where'.
        /// </summary>
        public const string WHERE = "WHERE";
        /// <summary>
        /// Represents the keyword 'order'.
        /// </summary>
        public const string ORDER = "ORDER";
        /// <summary>
        /// Represents the keyword 'by'.
        /// </summary>
        public const string BY = "BY";
    }
}
