﻿using System.Text;
using System.IO;
using System.Reflection;

namespace CodeGenerator.Common
{
    /// <summary>
    /// The class that creates the files.
    /// </summary>
    public class FileCreator
    {
        private UIEntryStore uiEntryStore;

        /// <summary>
        /// The constructor that initializes the file creator class.
        /// </summary>
        /// <param name="uiEntryStore">The class that stores all the values that are entered in the ui.</param>
        public FileCreator(UIEntryStore uiEntryStore)
        {
            this.uiEntryStore = uiEntryStore;
        }

        /// <summary>
        /// The method that creates the file.
        /// </summary>
        /// <param name="fileFullPath">The full path where the file is to be created.</param>
        /// <param name="fileContents">The contents that are to be written in the file.</param>
        private void CreateFile(string fileFullPath, string fileContents)
        {
            File.WriteAllText(fileFullPath, fileContents);
        }

        /// <summary>
        /// The method that checks whether the specified directory exists or not and creates the directory.
        /// </summary>
        /// <param name="directoryPath">The path where the directory to be checked and created.</param>
        private void CheckAndCreateDirectory(string directoryPath)
        {
            if (!Directory.Exists(directoryPath))
                Directory.CreateDirectory(directoryPath);
        }

        private string CreateFullPath(string classFilePath, string[] parentDirectories)
        {
            string classFullPath = classFilePath;
            foreach (string directory in parentDirectories)
            {
                classFullPath = classFullPath + @"\" + directory;
                CheckAndCreateDirectory(classFullPath);
            }
            return classFullPath;
        }

        /// <summary>
        /// The method that creates the value object class file.
        /// </summary>
        /// <returns>Returns the path where the class file is created.</returns>
        public string CreateVOClass()
        {
            StringBuilder voBuilder = new StringBuilder();
            string fileExtension  ="";
            if (uiEntryStore.ClassFileLanguage == ClassLanguages.VisualBasic)
            {
                fileExtension = GeneralWords.VB_FILE_EXTENSION;
                voBuilder.AppendLine(string.Format("{0} {1}", VBKeywords.IMPORTS, "System"));
                voBuilder.AppendLine();
                voBuilder.AppendLine(string.Format("{0} {1}", VBKeywords.NAMESPACE, uiEntryStore.VONamespace));
                voBuilder.AppendLine(string.Format("{0}{1} {2} {3}", SpecialCharacters.HORIZONTAL_TAB, VBKeywords.PUBLIC, VBKeywords.CLASS, uiEntryStore.VOClassName));
                voBuilder.AppendLine();
                foreach (ColumnInformation colInfo in uiEntryStore.ColumnsInformation)
                {
                    string colType = colInfo.VBType;
                    string colName = colInfo.Name;
                    string sqlName = "_" + colInfo.SqlName;
                    voBuilder.AppendLine(string.Format("{0}{0}{1} {2} {3} {4}", SpecialCharacters.HORIZONTAL_TAB, VBKeywords.PRIVATE, sqlName, VBKeywords.AS, colType));
                    voBuilder.AppendLine(string.Format("{0}{0}{1} {2} {3}{4}{5} {6} {7}", SpecialCharacters.HORIZONTAL_TAB, VBKeywords.PUBLIC, VBKeywords.PROPERTY, colName, SpecialCharacters.LEFT_PARENTHESIS, SpecialCharacters.RIGHT_PARENTHESIS, VBKeywords.AS, colType));
                    voBuilder.AppendLine(string.Format("{0}{0}{0}{1}", SpecialCharacters.HORIZONTAL_TAB, VBKeywords.GET));
                    voBuilder.AppendLine(string.Format("{0}{0}{0}{0}{1} {2}", SpecialCharacters.HORIZONTAL_TAB, VBKeywords.RETURN, sqlName));
                    voBuilder.AppendLine(string.Format("{0}{0}{1} {2}", SpecialCharacters.HORIZONTAL_TAB, VBKeywords.END, VBKeywords.GET));
                    voBuilder.AppendLine(string.Format("{0}{0}{0}{1}{2}{3} value {4} {5}{6}", SpecialCharacters.HORIZONTAL_TAB, VBKeywords.SET, SpecialCharacters.LEFT_PARENTHESIS, VBKeywords.BYVAL, VBKeywords.AS, colType, SpecialCharacters.RIGHT_PARENTHESIS));
                    voBuilder.AppendLine(string.Format("{0}{0}{0}{0}{1} = value", SpecialCharacters.HORIZONTAL_TAB, sqlName));
                    voBuilder.AppendLine(string.Format("{0}{0}{0}{1} {2}", SpecialCharacters.HORIZONTAL_TAB, VBKeywords.END, VBKeywords.SET));
                    voBuilder.AppendLine(string.Format("{0}{0}{1} {2}", SpecialCharacters.HORIZONTAL_TAB, VBKeywords.END, VBKeywords.PROPERTY));
                    voBuilder.AppendLine();
                }
                voBuilder.AppendLine(string.Format("{0}{0}{1} {2} {3}{4}{5}", SpecialCharacters.HORIZONTAL_TAB, VBKeywords.PUBLIC, VBKeywords.SUB, VBKeywords.NEW, SpecialCharacters.LEFT_PARENTHESIS, SpecialCharacters.RIGHT_PARENTHESIS));
                voBuilder.AppendLine(string.Format("{0}{0}{0}{1}.{2}{3}{4}", SpecialCharacters.HORIZONTAL_TAB, VBKeywords.MYBASE, VBKeywords.NEW, SpecialCharacters.LEFT_PARENTHESIS, SpecialCharacters.RIGHT_PARENTHESIS));
                voBuilder.AppendLine(string.Format("{0}{0}{1} {2}", SpecialCharacters.HORIZONTAL_TAB, VBKeywords.END, VBKeywords.SUB));
                voBuilder.AppendLine(string.Format("{0}{1} {2}", SpecialCharacters.HORIZONTAL_TAB, VBKeywords.END, VBKeywords.CLASS));
                voBuilder.AppendLine(string.Format("{0} {1}", VBKeywords.END, VBKeywords.NAMESPACE));
            }
            else
            {
                fileExtension = GeneralWords.CS_FILE_EXTENSION;
                voBuilder.AppendLine(string.Format("{0} {1}{2}", CSKeywords.USING, "System", SpecialCharacters.SEMI_COLON));
                voBuilder.AppendLine();
                voBuilder.AppendLine(string.Format("{0} {1}", CSKeywords.NAMESPACE, uiEntryStore.VONamespace));
                voBuilder.AppendLine(SpecialCharacters.LEFT_CURLY_BRACKET);
                voBuilder.AppendLine(string.Format("{0}{1} {2} {3}", SpecialCharacters.HORIZONTAL_TAB, CSKeywords.PUBLIC, CSKeywords.CLASS, uiEntryStore.VOClassName));
                voBuilder.AppendLine(string.Format("{0}{1}", SpecialCharacters.HORIZONTAL_TAB, SpecialCharacters.LEFT_CURLY_BRACKET));
                foreach (ColumnInformation colInfo in uiEntryStore.ColumnsInformation)
                {
                    string colType = colInfo.CSType;
                    string colName = colInfo.Name;
                    voBuilder.AppendLine(string.Format("{0}{0}{1} {2} {3} {4} {5}{6} {7}{6} {8}", SpecialCharacters.HORIZONTAL_TAB, CSKeywords.PUBLIC, colType, colName, SpecialCharacters.LEFT_CURLY_BRACKET, CSKeywords.GET, SpecialCharacters.SEMI_COLON, CSKeywords.SET, SpecialCharacters.RIGHT_CURLY_BRACKET));
                    voBuilder.AppendLine();
                }
                voBuilder.AppendLine(string.Format("{0}{0}{1} {2}{3}{4}", SpecialCharacters.HORIZONTAL_TAB, CSKeywords.PUBLIC, uiEntryStore.VOClassName, SpecialCharacters.LEFT_PARENTHESIS, SpecialCharacters.RIGHT_PARENTHESIS));
                voBuilder.AppendLine(string.Format("{0}{0}{1}", SpecialCharacters.HORIZONTAL_TAB, SpecialCharacters.LEFT_CURLY_BRACKET));
                voBuilder.AppendLine(string.Format("{0}{0}{1}", SpecialCharacters.HORIZONTAL_TAB, SpecialCharacters.RIGHT_CURLY_BRACKET));
                voBuilder.AppendLine(string.Format("{0}{1}", SpecialCharacters.HORIZONTAL_TAB, SpecialCharacters.RIGHT_CURLY_BRACKET));
                voBuilder.AppendLine(SpecialCharacters.RIGHT_CURLY_BRACKET);
            }
            string voFilePath = CommonFunctions.CreateValidPath(uiEntryStore.FileLocation);
            CheckAndCreateDirectory(voFilePath);
            voFilePath = CreateFullPath(CommonFunctions.CreateValidPath(voFilePath), uiEntryStore.VOParentDirectories);
            voFilePath = string.Format("{0}{1}{2}", CommonFunctions.CreateValidPath(voFilePath), uiEntryStore.VOClassName, fileExtension);
            CreateFile(voFilePath, voBuilder.ToString());
            return voFilePath;
        }

        /// <summary>
        /// The method that creates the business logic layer class file.
        /// </summary>
        /// <returns>Returns the path where the class file is created.</returns>
        public string CreateBLLClass()
        {
            Assembly thisAssembly = Assembly.GetExecutingAssembly();
            string templateFile = "CodeGenerator.Common.CSBLLTemplate.txt";
            string fileExtension = GeneralWords.CS_FILE_EXTENSION;
            if (uiEntryStore.ClassFileLanguage == ClassLanguages.VisualBasic)
            {
                templateFile = "CodeGenerator.Common.VBBLLTemplate.txt";
                fileExtension = GeneralWords.VB_FILE_EXTENSION;
            }
            StreamReader textStreamReader = new StreamReader(thisAssembly.GetManifestResourceStream(templateFile));
            string contents = textStreamReader.ReadToEnd();
            contents = contents.Replace("<VONamespace>", uiEntryStore.VONamespace);
            contents = contents.Replace("<BLLNamespace>", uiEntryStore.BLLNamespace);
            contents = contents.Replace("<BLLClassName>", uiEntryStore.BLLClassName);
            contents = contents.Replace("<VOClassName>", uiEntryStore.VOClassName);
            contents = contents.Replace("<VOClassObject>", uiEntryStore.VOClassName.ToLower());
            contents = contents.Replace("<DALNamespace>", uiEntryStore.DALNamespace);
            contents = contents.Replace("<DALClassName>", uiEntryStore.DALClassName);
            contents = contents.Replace("<DALClassObject>", string.Format("{0}{1}", uiEntryStore.VOClassName.ToLower(), GeneralWords.DAL_CLASS_SUFFIX));
            string bllFilePath = CommonFunctions.CreateValidPath(uiEntryStore.FileLocation);
            CheckAndCreateDirectory(bllFilePath);
            bllFilePath = CreateFullPath(CommonFunctions.CreateValidPath(bllFilePath), uiEntryStore.BLLParentDirectories);
            bllFilePath = string.Format("{0}{1}{2}", CommonFunctions.CreateValidPath(bllFilePath), uiEntryStore.BLLClassName, fileExtension);
            CreateFile(bllFilePath, contents);
            return bllFilePath;
        }

        /// <summary>
        /// The method that creates the data access layer class file.
        /// </summary>
        /// <returns>Returns the path where the class file is created.</returns>
        public string CreateDALClass()
        {
            Assembly thisAssembly = Assembly.GetExecutingAssembly();
            string templateFile = "CodeGenerator.Common.CSDALTemplate.txt";
            string fileExtension = GeneralWords.CS_FILE_EXTENSION;
            if (uiEntryStore.ClassFileLanguage == ClassLanguages.VisualBasic)
            {
                templateFile = "CodeGenerator.Common.VBDALTemplate.txt";
                fileExtension = GeneralWords.VB_FILE_EXTENSION;
            }
            StreamReader textStreamReader = new StreamReader(thisAssembly.GetManifestResourceStream(templateFile));
            string contents = textStreamReader.ReadToEnd();
            contents = contents.Replace("<VONamespace>", uiEntryStore.VONamespace);
            contents = contents.Replace("<DALNamespace>", uiEntryStore.DALNamespace);
            contents = contents.Replace("<DALClassName>", uiEntryStore.DALClassName);
            contents = contents.Replace("<VOClassName>", uiEntryStore.VOClassName);
            contents = contents.Replace("<VOClassObject>", uiEntryStore.VOClassName.ToLower());
            contents = contents.Replace("<ConnectionString>", string.Format("data source={0}; initial catalog={1}; user id={2}; password={3}; Integrated Security=SSPI", uiEntryStore.ServerInstance, uiEntryStore.DatabaseName, uiEntryStore.ServerUsername, uiEntryStore.ServerPassword));
            contents = contents.Replace("<SelectColumns>", CreateSelectColumns());
            contents = contents.Replace("<SelectQuery>", CreateSelectQuery());
            contents = contents.Replace("<InsertQuery>", CreateInsertQuery());
            contents = contents.Replace("<UpdateQuery>", CreateUpdateQuery());
            contents = contents.Replace("<DeleteQuery>", CreateDeleteQuery());
            contents = contents.Replace("<PrimaryKey>", CommonFunctions.CreateGoodName(uiEntryStore.PrimaryKey));
            contents = contents.Replace("<ToTableColumns>", CreateParametersString());
            string dalFilePath = CommonFunctions.CreateValidPath(uiEntryStore.FileLocation);
            CheckAndCreateDirectory(dalFilePath);
            dalFilePath = CreateFullPath(CommonFunctions.CreateValidPath(dalFilePath), uiEntryStore.DALParentDirectories);
            dalFilePath = string.Format("{0}{1}{2}", CommonFunctions.CreateValidPath(dalFilePath), uiEntryStore.DALClassName, fileExtension);
            CreateFile(dalFilePath, contents);
            return dalFilePath;
        }

        /// <summary>
        /// The method that creates the select columns.
        /// </summary>
        /// <returns>Returns the select column contents.</returns>
        private string CreateSelectColumns()
        {
            StringBuilder scBuilder = new StringBuilder();
            string lineTerminator = SpecialCharacters.SEMI_COLON;
            if (uiEntryStore.ClassFileLanguage == ClassLanguages.VisualBasic)
                lineTerminator = "";
            foreach (ColumnInformation colInformation in uiEntryStore.ColumnsInformation)
            {
                string colName = colInformation.Name;
                
                string selectString = ConvertTypeForCS(colInformation.CSType, colInformation.SqlName);
                if (uiEntryStore.ClassFileLanguage == ClassLanguages.VisualBasic)
                {
                    selectString = ConvertTypeForVB(colInformation.VBType, colInformation.SqlName);
                }
                scBuilder.AppendLine(string.Format("{0}{0}{0}{0}{0}{1}.{2} = {3}{4}", SpecialCharacters.HORIZONTAL_TAB, uiEntryStore.VOClassName.ToLower(), colName, selectString, lineTerminator));
            }
            return scBuilder.ToString();
        }

        /// <summary>
        /// The method that creates the select query.
        /// </summary>
        /// <returns>Returns the select query string.</returns>
        private string CreateSelectQuery()
        {
            StringBuilder sqBuilder = new StringBuilder();
            sqBuilder.Append(SqlKeywords.SELECT);
            sqBuilder.Append(" * ");
            sqBuilder.Append(SqlKeywords.FROM);
            sqBuilder.Append(" ");
            sqBuilder.Append(uiEntryStore.TableName);
            return sqBuilder.ToString();
        }

        /// <summary>
        /// The method that creates the insert query.
        /// </summary>
        /// <returns>Returns the insert query string.</returns>
        private string CreateInsertQuery()
        {
            StringBuilder iqBuilder = new StringBuilder();
            iqBuilder.Append(SqlKeywords.INSERT);
            iqBuilder.Append(" ");
            iqBuilder.Append(SqlKeywords.INTO);
            iqBuilder.Append(" ");
            iqBuilder.Append(uiEntryStore.TableName);
            iqBuilder.Append(SpecialCharacters.LEFT_PARENTHESIS);
            string columnsString = "";
            string valuesString = "";
            foreach (ColumnInformation colInformation in uiEntryStore.ColumnsInformation)
            {
                if (colInformation.SqlName != uiEntryStore.PrimaryKey)
                {
                    columnsString += SpecialCharacters.LEFT_BRACKET + colInformation.SqlName + SpecialCharacters.RIGHT_BRACKET + ", ";
                    valuesString += "@" + colInformation.SqlName + ", ";
                }
            }
            columnsString = columnsString.TrimEnd(',', ' ');
            valuesString = valuesString.TrimEnd(',', ' ');
            iqBuilder.Append(columnsString);
            iqBuilder.Append(SpecialCharacters.RIGHT_PARENTHESIS);
            iqBuilder.Append(" ");
            iqBuilder.Append(SqlKeywords.VALUES);
            iqBuilder.Append(SpecialCharacters.LEFT_PARENTHESIS);
            iqBuilder.Append(valuesString);
            iqBuilder.Append(SpecialCharacters.RIGHT_PARENTHESIS);
            return iqBuilder.ToString();
        }

        /// <summary>
        /// The method that creates the update query.
        /// </summary>
        /// <returns>Returns the update query string.</returns>
        private string CreateUpdateQuery()
        {
            StringBuilder uqBuilder = new StringBuilder();
            uqBuilder.Append(SqlKeywords.UPDATE);
            uqBuilder.Append(" ");
            uqBuilder.Append(uiEntryStore.TableName);
            uqBuilder.Append(" ");
            uqBuilder.Append(SqlKeywords.SET);
            uqBuilder.Append(" ");
            string valuesString = "";
            foreach (ColumnInformation colInformation in uiEntryStore.ColumnsInformation)
            {
                if (colInformation.SqlName != uiEntryStore.PrimaryKey)
                    valuesString += string.Format("{0}{1}{2}=@{1}, ", SpecialCharacters.LEFT_BRACKET, colInformation.SqlName, SpecialCharacters.RIGHT_BRACKET);
            }
            valuesString = valuesString.TrimEnd(',', ' ');
            uqBuilder.Append(valuesString);
            uqBuilder.Append(" ");
            uqBuilder.Append(SqlKeywords.WHERE);
            uqBuilder.Append(" ");
            uqBuilder.Append(SpecialCharacters.LEFT_BRACKET);
            uqBuilder.Append(uiEntryStore.PrimaryKey);
            uqBuilder.Append(SpecialCharacters.RIGHT_BRACKET);
            uqBuilder.Append(" = {0}");
            return uqBuilder.ToString();
        }

        /// <summary>
        /// The method that creates the parameters string.
        /// </summary>
        /// <returns>Returns the parameters string.</returns>
        private string CreateParametersString()
        {
            StringBuilder spBuilder = new StringBuilder();
            string lineTerminator = SpecialCharacters.SEMI_COLON;
            if (uiEntryStore.ClassFileLanguage == ClassLanguages.VisualBasic)
                lineTerminator = "";
            foreach (ColumnInformation colInformation in uiEntryStore.ColumnsInformation)
            {
                if (colInformation.SqlName != uiEntryStore.PrimaryKey)
                    spBuilder.AppendLine(string.Format("{0}{0}{0}{0}sqlCommand.Parameters.AddWithValue{1}\"@{2}\", {3}.{4}{5}{6}", SpecialCharacters.HORIZONTAL_TAB, SpecialCharacters.LEFT_PARENTHESIS, colInformation.SqlName, uiEntryStore.VOClassName.ToLower(), colInformation.Name, SpecialCharacters.RIGHT_PARENTHESIS, lineTerminator));
            }
            return spBuilder.ToString();
        }

        /// <summary>
        /// The method that creates the delete query.
        /// </summary>
        /// <returns>Returns the delete query string.</returns>
        private string CreateDeleteQuery()
        {
            StringBuilder dqBuilder = new StringBuilder();
            dqBuilder.Append(SqlKeywords.DELETE);
            dqBuilder.Append(" ");
            dqBuilder.Append(SqlKeywords.FROM);
            dqBuilder.Append(" ");
            dqBuilder.Append(uiEntryStore.TableName);
            dqBuilder.Append(" ");
            dqBuilder.Append(SqlKeywords.WHERE);
            dqBuilder.Append(" ");
            dqBuilder.Append(SpecialCharacters.LEFT_BRACKET);
            dqBuilder.Append(uiEntryStore.PrimaryKey);
            dqBuilder.Append(SpecialCharacters.RIGHT_BRACKET);
            dqBuilder.Append(" = {0}");
            return dqBuilder.ToString();
        }

        /// <summary>
        /// The method that converts the sql type to the cs type.
        /// </summary>
        /// <param name="type">The sql column type.</param>
        /// <param name="name">The sql column name.</param>
        /// <returns>Returns the cs type string.</returns>
        private string ConvertTypeForCS(string type, string name)
        {
            string returnValue = "";
            switch (type)
            {
                case "int":
                    returnValue = "Convert.ToInt32(sdr[\"" + name + "\"])";
                    break;
                case "bool":
                    returnValue = "Convert.ToBoolean(sdr[\"" + name + "\"])";
                    break;
                case "DateTime":
                    returnValue = "Convert.ToDateTime(sdr[\"" + name + "\"])";
                    break;
                case "float":
                    returnValue = "Convert.ToSingle(sdr[\"" + name + "\"])";
                    break;
                case "double":
                    returnValue = "Convert.ToDouble(sdr[\"" + name + "\"])";
                    break;
                case "object":
                    returnValue = "sdr[\"" + name + "\"]";
                    break;
                default:
                    returnValue = "Convert.ToString(sdr[\"" + name + "\"])";
                    break;
            }
            return returnValue;
        }

        /// <summary>
        /// The method that converts the sql type to the vb type.
        /// </summary>
        /// <param name="type">The sql column type.</param>
        /// <param name="name">The sql column name.</param>
        /// <returns>Returns the vb type string.</returns>
        private string ConvertTypeForVB(string type, string name)
        {
            string returnValue = "";
            switch (type)
            {
                case "Integer":
                    returnValue = "CType(sdr(\"" + name + "\"), Integer)";
                    break;
                case "Boolean":
                    returnValue = "CType(sdr(\"" + name + "\"), Boolean)";
                    break;
                case "DateTime":
                    returnValue = "CType(sdr(\"" + name + "\"), DateTime)";
                    break;
                case "Single":
                    returnValue = "CType(sdr(\"" + name + "\"), Single)";
                    break;
                case "Double":
                    returnValue = "CType(sdr(\"" + name + "\"), Double)";
                    break;
                case "Object":
                    returnValue = "sdr(\"" + name + "\")";
                    break;
                default:
                    returnValue = "CType(sdr(\"" + name + "\"), String)";
                    break;
            }
            return returnValue;
        }
    }
}
