﻿using System.Windows.Forms;

namespace CodeGenerator.Common
{
    /// <summary>
    /// The class that contains all common functions.
    /// </summary>
    public class CommonFunctions
    {
        /// <summary>
        /// The class that holds the sql server handling events.
        /// </summary>
        public static SqlServerHandler SqlServerEventHandler { get; set; }

        /// <summary>
        /// The method that creates a good name for the specified name.
        /// </summary>
        /// <param name="name">The name for which a good name is created.</param>
        /// <returns>Returns the good name of the specified name.</returns>
        public static string CreateGoodName(string name)
        {
            name = name.Replace("_", "").Replace(" ", "");
            char[] chars = name.ToCharArray();
            string firstChar = chars[0].ToString();
            firstChar = firstChar.ToUpper();
            chars[0] = System.Convert.ToChar(firstChar);
            return new string(chars);
        }

        /// <summary>
        /// The method that creates a valid path of the specified path.
        /// </summary>
        /// <param name="path">The path for which a valid path is created.</param>
        /// <returns>Returns the valid path of the specified path.</returns>
        public static string CreateValidPath(string path)
        {
            if (!path.EndsWith(@"\"))
                path = path + @"\";
            return path;
        }

        /// <summary>
        /// The method that displays a message box in the ui.
        /// </summary>
        /// <param name="message">The message that to be displayed in the message box.</param>
        /// <param name="messageBoxButtons">The buttons that are to be displayed in the message box.</param>
        /// <param name="messageBoxIcon">The icon that is to be displayed in the message box.</param>
        /// <returns>Returns the dialog result of the message box.</returns>
        public static DialogResult ShowMessageBox(string message, MessageBoxButtons messageBoxButtons, MessageBoxIcon messageBoxIcon)
        {
            return MessageBox.Show(message, "Class Generator", messageBoxButtons, messageBoxIcon);
        }
    }
}
