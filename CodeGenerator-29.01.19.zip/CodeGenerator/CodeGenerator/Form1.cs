﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CodeGenerator.Common;

namespace CodeGenerator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        #region Server Box

        private void btnConnect_Click(object sender, System.EventArgs e)
        {
            try
            {
                ServerBox serverBox = bindServerBox();
                ServerBoxEvents serverBoxEvent = new ServerBoxEvents(serverBox);
                if (!chkIsWindowsAuth.Checked && serverBox.IsValuesEmpty)
                {
                    CommonFunctions.ShowMessageBox("Please enter Server Name, Username and Password!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    bool connectionResult = serverBoxEvent.Connect();
                    if (connectionResult)
                    {
                        cmbDatabases.DataSource = CommonFunctions.SqlServerEventHandler.GetDatabases();
                        CommonFunctions.ShowMessageBox("Connection successful!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                        CommonFunctions.ShowMessageBox("Connection failed, please check whether the server name, username and password are correct!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                CommonFunctions.ShowMessageBox("Error occured while establishing a connection." + Environment.NewLine + "Please debug the error: " + ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void chkIsWindowsAuth_CheckedChanged(object sender, EventArgs e)
        {
            txtUsername.Text = txtPassword.Text = "";
            txtUsername.Enabled = txtPassword.Enabled = !chkIsWindowsAuth.Checked;
        }
        private ServerBox bindServerBox()
        {
            ServerBox serverBox = new ServerBox();
            serverBox.ServerInstance = txtServerName.Text.Trim();
            serverBox.ServerUsername = txtUsername.Text.Trim();
            serverBox.ServerPassword = txtPassword.Text.Trim();
            serverBox.IsWindowsAuth = chkIsWindowsAuth.Checked;
            return serverBox;
        }

        #endregion

        #region DataBase Box

        private void cmbDatabases_SelectedIndexChanged(object sender, EventArgs e)
        {
            //DatabaseBox databaseBox = bindDatabaseBox();
            //DatabaseBoxEvents databaseBoxEvents = new DatabaseBoxEvents(databaseBox);
            cmbTables.DataSource = CommonFunctions.SqlServerEventHandler.GetTables(cmbDatabases.Text);
        }
        private void cmbTables_SelectedIndexChanged(object sender, EventArgs e)
        {
            string SelectedDatabase = cmbDatabases.Text;
            string SelectedTable = cmbTables.Text;
            lblPKValue.Text = CommonFunctions.SqlServerEventHandler.GetPrimaryKey(SelectedDatabase, SelectedTable);

            string goodDatabaseName = CommonFunctions.CreateGoodName(SelectedDatabase.ToLower());
            string goodVONamespace = goodDatabaseName + "." + GeneralWords.VO_CLASS_NAMESPACE;
            string goodVOClassName = CommonFunctions.CreateGoodName(SelectedTable);
            txtVONamespace.Text = goodVONamespace;
            txtVOClassname.Text = goodVOClassName;

            string goodBLLNamespace = goodDatabaseName + "." + GeneralWords.BLL_CLASS_NAMESPACE;
            string goodBLLClassName = CommonFunctions.CreateGoodName(SelectedTable) + GeneralWords.BLL_CLASS_SUFFIX;
            txtBLLClassname.Text = goodBLLClassName;
            txtBLLNamespace.Text = goodBLLNamespace;

            string goodDALNamespace = goodDatabaseName + "." + GeneralWords.DAL_CLASS_NAMESPACE;
            string goodDALClassName = CommonFunctions.CreateGoodName(SelectedTable) + GeneralWords.DAL_CLASS_SUFFIX;
            txtDALNamespace.Text = goodDALNamespace;
            txtDALClassname.Text = goodDALClassName;
        }

        #endregion


        #region Generator

        private void btnBrowse_Click(object sender, System.EventArgs e)
        {
            if (fldBrowseDialog.ShowDialog() == DialogResult.OK)
                txtLocation.Text = fldBrowseDialog.SelectedPath;
        }
        private void btnClassGenerator_Click(object sender, EventArgs e)
        {
            try
            {
                ServerBox serverBox = bindServerBox();
                if (
                    (!serverBox.IsWindowsAuth & serverBox.IsValuesEmpty)

                    || string.IsNullOrWhiteSpace(txtLocation.Text.Trim())

                    || string.IsNullOrWhiteSpace(txtBLLClassname.Text.Trim())
                    || string.IsNullOrWhiteSpace(txtBLLNamespace.Text.Trim())

                    || string.IsNullOrWhiteSpace(txtDALClassname.Text.Trim())
                    || string.IsNullOrWhiteSpace(txtDALNamespace.Text.Trim())

                    || string.IsNullOrWhiteSpace(txtVOClassname.Text.Trim())
                    || string.IsNullOrWhiteSpace(txtVONamespace.Text.Trim())

                    )
                {
                    CommonFunctions.ShowMessageBox("Please enter all the required fields! ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    UIEntryStore uiEntryStore = new UIEntryStore();
                    uiEntryStore.ServerInstance = serverBox.ServerInstance;
                    uiEntryStore.ServerUsername = serverBox.ServerUsername;
                    uiEntryStore.ServerPassword = serverBox.ServerPassword;
                    uiEntryStore.DatabaseName =  cmbDatabases.Text;
                    uiEntryStore.TableName = cmbTables.Text;
                    uiEntryStore.PrimaryKey = lblPKValue.Text;
                    uiEntryStore.ColumnsInformation = CommonFunctions.SqlServerEventHandler.GetTableColumns(cmbDatabases.Text, cmbTables.Text);
                    uiEntryStore.FileLocation = txtLocation.Text;
                    uiEntryStore.VOClassName = txtVOClassname.Text.Trim();
                    uiEntryStore.VONamespace = txtVONamespace.Text.Trim();
                    uiEntryStore.VOParentDirectories = GetParentDirectories(txtVONamespace.Text.Trim());
                    uiEntryStore.BLLClassName = txtBLLClassname.Text.Trim();
                    uiEntryStore.BLLNamespace = txtBLLNamespace.Text.Trim();
                    uiEntryStore.BLLParentDirectories = GetParentDirectories(txtBLLNamespace.Text.Trim()); 
                    uiEntryStore.DALClassName = txtDALClassname.Text.Trim();
                    uiEntryStore.DALNamespace = txtDALNamespace.Text.Trim();
                    uiEntryStore.DALParentDirectories = GetParentDirectories(txtDALNamespace.Text.Trim());
                    uiEntryStore.ClassFileLanguage = rdoCSharp.Checked ? ClassLanguages.CSharp : ClassLanguages.VisualBasic;
                    this.grpGenInfo.Text = CreateClassFiles(uiEntryStore);
                }
            }
            catch (Exception ex)
            {
                CommonFunctions.ShowMessageBox("Error occured while creating class files." + Environment.NewLine + "Please debug the error: " + ex.Message, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private string CreateClassFiles(UIEntryStore uiEntryStore)
        {
            FileCreator fileCreator = new FileCreator(uiEntryStore);
            System.Text.StringBuilder resultBuilder = new System.Text.StringBuilder();
            resultBuilder.AppendLine(fileCreator.CreateVOClass());
            resultBuilder.AppendLine(fileCreator.CreateBLLClass());
            resultBuilder.AppendLine(fileCreator.CreateDALClass());
            resultBuilder.AppendLine("Files are created successfully.!");
            return resultBuilder.ToString();
        }
        private string[] GetParentDirectories(string Namespace)
        {
            if (Namespace.IndexOf('.') == -1)
                return new string[] { Namespace };
            else
                return Namespace.Split('.');
        }

        #endregion

        
    }
}
