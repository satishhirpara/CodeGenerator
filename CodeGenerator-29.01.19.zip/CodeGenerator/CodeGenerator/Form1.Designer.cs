﻿namespace CodeGenerator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpServerInfo = new System.Windows.Forms.GroupBox();
            this.chkIsWindowsAuth = new System.Windows.Forms.CheckBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtServerName = new System.Windows.Forms.TextBox();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblServer = new System.Windows.Forms.Label();
            this.grpDBInfo = new System.Windows.Forms.GroupBox();
            this.lblPKValue = new System.Windows.Forms.Label();
            this.lblPK = new System.Windows.Forms.Label();
            this.cmbDatabases = new System.Windows.Forms.ComboBox();
            this.cmbTables = new System.Windows.Forms.ComboBox();
            this.lblTables = new System.Windows.Forms.Label();
            this.lblDatabases = new System.Windows.Forms.Label();
            this.grpLocation = new System.Windows.Forms.GroupBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.txtLocation = new System.Windows.Forms.TextBox();
            this.lblLocation = new System.Windows.Forms.Label();
            this.fldBrowseDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.lblGenInfo = new System.Windows.Forms.Label();
            this.grpGenInfo = new System.Windows.Forms.GroupBox();
            this.txtVOClassname = new System.Windows.Forms.TextBox();
            this.grpVOInfo = new System.Windows.Forms.GroupBox();
            this.lblVOClassname = new System.Windows.Forms.Label();
            this.txtVONamespace = new System.Windows.Forms.TextBox();
            this.lblVONamespace = new System.Windows.Forms.Label();
            this.grpBLLInfo = new System.Windows.Forms.GroupBox();
            this.txtBLLClassname = new System.Windows.Forms.TextBox();
            this.lblBLLClassname = new System.Windows.Forms.Label();
            this.txtBLLNamespace = new System.Windows.Forms.TextBox();
            this.lblBLLNamespace = new System.Windows.Forms.Label();
            this.grpDALInfo = new System.Windows.Forms.GroupBox();
            this.txtDALClassname = new System.Windows.Forms.TextBox();
            this.lblDALClassname = new System.Windows.Forms.Label();
            this.txtDALNamespace = new System.Windows.Forms.TextBox();
            this.lblDALNamespace = new System.Windows.Forms.Label();
            this.grpLanguageInfo = new System.Windows.Forms.GroupBox();
            this.rdoVB = new System.Windows.Forms.RadioButton();
            this.rdoCSharp = new System.Windows.Forms.RadioButton();
            this.lblLanguage = new System.Windows.Forms.Label();
            this.btnClassGenerator = new System.Windows.Forms.Button();
            this.grpServerInfo.SuspendLayout();
            this.grpDBInfo.SuspendLayout();
            this.grpLocation.SuspendLayout();
            this.grpGenInfo.SuspendLayout();
            this.grpVOInfo.SuspendLayout();
            this.grpBLLInfo.SuspendLayout();
            this.grpDALInfo.SuspendLayout();
            this.grpLanguageInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpServerInfo
            // 
            this.grpServerInfo.AutoSize = true;
            this.grpServerInfo.Controls.Add(this.chkIsWindowsAuth);
            this.grpServerInfo.Controls.Add(this.btnConnect);
            this.grpServerInfo.Controls.Add(this.txtPassword);
            this.grpServerInfo.Controls.Add(this.txtUsername);
            this.grpServerInfo.Controls.Add(this.txtServerName);
            this.grpServerInfo.Controls.Add(this.lblPassword);
            this.grpServerInfo.Controls.Add(this.lblUsername);
            this.grpServerInfo.Controls.Add(this.lblServer);
            this.grpServerInfo.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpServerInfo.ForeColor = System.Drawing.Color.Black;
            this.grpServerInfo.Location = new System.Drawing.Point(12, 12);
            this.grpServerInfo.Name = "grpServerInfo";
            this.grpServerInfo.Size = new System.Drawing.Size(314, 155);
            this.grpServerInfo.TabIndex = 9;
            this.grpServerInfo.TabStop = false;
            this.grpServerInfo.Text = "Server";
            // 
            // chkIsWindowsAuth
            // 
            this.chkIsWindowsAuth.AutoSize = true;
            this.chkIsWindowsAuth.Location = new System.Drawing.Point(19, 117);
            this.chkIsWindowsAuth.Name = "chkIsWindowsAuth";
            this.chkIsWindowsAuth.Size = new System.Drawing.Size(154, 17);
            this.chkIsWindowsAuth.TabIndex = 13;
            this.chkIsWindowsAuth.Text = "Is Windows Authentication";
            this.chkIsWindowsAuth.UseVisualStyleBackColor = true;
            this.chkIsWindowsAuth.CheckedChanged += new System.EventHandler(this.chkIsWindowsAuth_CheckedChanged);
            // 
            // btnConnect
            // 
            this.btnConnect.AutoSize = true;
            this.btnConnect.ForeColor = System.Drawing.Color.Black;
            this.btnConnect.Location = new System.Drawing.Point(223, 112);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 23);
            this.btnConnect.TabIndex = 12;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // txtPassword
            // 
            this.txtPassword.ForeColor = System.Drawing.Color.Black;
            this.txtPassword.Location = new System.Drawing.Point(81, 83);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(217, 21);
            this.txtPassword.TabIndex = 11;
            // 
            // txtUsername
            // 
            this.txtUsername.ForeColor = System.Drawing.Color.Black;
            this.txtUsername.Location = new System.Drawing.Point(81, 54);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(217, 21);
            this.txtUsername.TabIndex = 10;
            // 
            // txtServerName
            // 
            this.txtServerName.ForeColor = System.Drawing.Color.Black;
            this.txtServerName.Location = new System.Drawing.Point(81, 25);
            this.txtServerName.Name = "txtServerName";
            this.txtServerName.Size = new System.Drawing.Size(217, 21);
            this.txtServerName.TabIndex = 9;
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassword.ForeColor = System.Drawing.Color.Black;
            this.lblPassword.Location = new System.Drawing.Point(16, 87);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(57, 13);
            this.lblPassword.TabIndex = 8;
            this.lblPassword.Text = "Password:";
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsername.ForeColor = System.Drawing.Color.Black;
            this.lblUsername.Location = new System.Drawing.Point(16, 58);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(59, 13);
            this.lblUsername.TabIndex = 7;
            this.lblUsername.Text = "Username:";
            // 
            // lblServer
            // 
            this.lblServer.AutoSize = true;
            this.lblServer.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServer.ForeColor = System.Drawing.Color.Black;
            this.lblServer.Location = new System.Drawing.Point(16, 29);
            this.lblServer.Name = "lblServer";
            this.lblServer.Size = new System.Drawing.Size(43, 13);
            this.lblServer.TabIndex = 6;
            this.lblServer.Text = "Server:";
            // 
            // grpDBInfo
            // 
            this.grpDBInfo.AutoSize = true;
            this.grpDBInfo.Controls.Add(this.lblPKValue);
            this.grpDBInfo.Controls.Add(this.lblPK);
            this.grpDBInfo.Controls.Add(this.cmbDatabases);
            this.grpDBInfo.Controls.Add(this.cmbTables);
            this.grpDBInfo.Controls.Add(this.lblTables);
            this.grpDBInfo.Controls.Add(this.lblDatabases);
            this.grpDBInfo.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpDBInfo.ForeColor = System.Drawing.Color.Black;
            this.grpDBInfo.Location = new System.Drawing.Point(12, 169);
            this.grpDBInfo.Name = "grpDBInfo";
            this.grpDBInfo.Size = new System.Drawing.Size(314, 115);
            this.grpDBInfo.TabIndex = 10;
            this.grpDBInfo.TabStop = false;
            this.grpDBInfo.Text = "Database";
            // 
            // lblPKValue
            // 
            this.lblPKValue.AutoSize = true;
            this.lblPKValue.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPKValue.Location = new System.Drawing.Point(149, 83);
            this.lblPKValue.Name = "lblPKValue";
            this.lblPKValue.Size = new System.Drawing.Size(0, 13);
            this.lblPKValue.TabIndex = 13;
            // 
            // lblPK
            // 
            this.lblPK.AutoSize = true;
            this.lblPK.Location = new System.Drawing.Point(81, 83);
            this.lblPK.Name = "lblPK";
            this.lblPK.Size = new System.Drawing.Size(68, 13);
            this.lblPK.TabIndex = 12;
            this.lblPK.Text = "Primary Key:";
            // 
            // cmbDatabases
            // 
            this.cmbDatabases.BackColor = System.Drawing.Color.White;
            this.cmbDatabases.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDatabases.FormattingEnabled = true;
            this.cmbDatabases.Location = new System.Drawing.Point(81, 25);
            this.cmbDatabases.Name = "cmbDatabases";
            this.cmbDatabases.Size = new System.Drawing.Size(217, 21);
            this.cmbDatabases.TabIndex = 11;
            this.cmbDatabases.SelectedIndexChanged += new System.EventHandler(this.cmbDatabases_SelectedIndexChanged);
            // 
            // cmbTables
            // 
            this.cmbTables.BackColor = System.Drawing.Color.White;
            this.cmbTables.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTables.FormattingEnabled = true;
            this.cmbTables.Location = new System.Drawing.Point(81, 54);
            this.cmbTables.Name = "cmbTables";
            this.cmbTables.Size = new System.Drawing.Size(217, 21);
            this.cmbTables.TabIndex = 10;
            this.cmbTables.SelectedIndexChanged += new System.EventHandler(this.cmbTables_SelectedIndexChanged);
            // 
            // lblTables
            // 
            this.lblTables.AutoSize = true;
            this.lblTables.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTables.ForeColor = System.Drawing.Color.Black;
            this.lblTables.Location = new System.Drawing.Point(16, 58);
            this.lblTables.Name = "lblTables";
            this.lblTables.Size = new System.Drawing.Size(42, 13);
            this.lblTables.TabIndex = 7;
            this.lblTables.Text = "Tables:";
            // 
            // lblDatabases
            // 
            this.lblDatabases.AutoSize = true;
            this.lblDatabases.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatabases.ForeColor = System.Drawing.Color.Black;
            this.lblDatabases.Location = new System.Drawing.Point(16, 29);
            this.lblDatabases.Name = "lblDatabases";
            this.lblDatabases.Size = new System.Drawing.Size(62, 13);
            this.lblDatabases.TabIndex = 6;
            this.lblDatabases.Text = "Databases:";
            // 
            // grpLocation
            // 
            this.grpLocation.Controls.Add(this.btnBrowse);
            this.grpLocation.Controls.Add(this.txtLocation);
            this.grpLocation.Controls.Add(this.lblLocation);
            this.grpLocation.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpLocation.ForeColor = System.Drawing.Color.Black;
            this.grpLocation.Location = new System.Drawing.Point(12, 286);
            this.grpLocation.Name = "grpLocation";
            this.grpLocation.Size = new System.Drawing.Size(314, 67);
            this.grpLocation.TabIndex = 13;
            this.grpLocation.TabStop = false;
            this.grpLocation.Text = "Location";
            // 
            // btnBrowse
            // 
            this.btnBrowse.AutoSize = true;
            this.btnBrowse.ForeColor = System.Drawing.Color.Black;
            this.btnBrowse.Location = new System.Drawing.Point(269, 25);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(29, 23);
            this.btnBrowse.TabIndex = 16;
            this.btnBrowse.Text = "...";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // txtLocation
            // 
            this.txtLocation.BackColor = System.Drawing.Color.White;
            this.txtLocation.ForeColor = System.Drawing.Color.Black;
            this.txtLocation.Location = new System.Drawing.Point(81, 26);
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.ReadOnly = true;
            this.txtLocation.Size = new System.Drawing.Size(182, 21);
            this.txtLocation.TabIndex = 15;
            // 
            // lblLocation
            // 
            this.lblLocation.AutoSize = true;
            this.lblLocation.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLocation.ForeColor = System.Drawing.Color.Black;
            this.lblLocation.Location = new System.Drawing.Point(16, 30);
            this.lblLocation.Name = "lblLocation";
            this.lblLocation.Size = new System.Drawing.Size(51, 13);
            this.lblLocation.TabIndex = 14;
            this.lblLocation.Text = "Location:";
            // 
            // lblGenInfo
            // 
            this.lblGenInfo.AutoSize = true;
            this.lblGenInfo.Location = new System.Drawing.Point(19, 19);
            this.lblGenInfo.Name = "lblGenInfo";
            this.lblGenInfo.Size = new System.Drawing.Size(0, 13);
            this.lblGenInfo.TabIndex = 0;
            // 
            // grpGenInfo
            // 
            this.grpGenInfo.Controls.Add(this.lblGenInfo);
            this.grpGenInfo.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpGenInfo.ForeColor = System.Drawing.Color.Black;
            this.grpGenInfo.Location = new System.Drawing.Point(12, 355);
            this.grpGenInfo.Name = "grpGenInfo";
            this.grpGenInfo.Size = new System.Drawing.Size(644, 82);
            this.grpGenInfo.TabIndex = 17;
            this.grpGenInfo.TabStop = false;
            this.grpGenInfo.Text = "Class Files Path";
            // 
            // txtVOClassname
            // 
            this.txtVOClassname.BackColor = System.Drawing.Color.White;
            this.txtVOClassname.ForeColor = System.Drawing.Color.Black;
            this.txtVOClassname.Location = new System.Drawing.Point(81, 54);
            this.txtVOClassname.Name = "txtVOClassname";
            this.txtVOClassname.Size = new System.Drawing.Size(217, 21);
            this.txtVOClassname.TabIndex = 15;
            // 
            // grpVOInfo
            // 
            this.grpVOInfo.Controls.Add(this.txtVOClassname);
            this.grpVOInfo.Controls.Add(this.lblVOClassname);
            this.grpVOInfo.Controls.Add(this.txtVONamespace);
            this.grpVOInfo.Controls.Add(this.lblVONamespace);
            this.grpVOInfo.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpVOInfo.ForeColor = System.Drawing.Color.Black;
            this.grpVOInfo.Location = new System.Drawing.Point(332, 12);
            this.grpVOInfo.Name = "grpVOInfo";
            this.grpVOInfo.Size = new System.Drawing.Size(314, 92);
            this.grpVOInfo.TabIndex = 18;
            this.grpVOInfo.TabStop = false;
            this.grpVOInfo.Text = "Value Object";
            // 
            // lblVOClassname
            // 
            this.lblVOClassname.AutoSize = true;
            this.lblVOClassname.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVOClassname.ForeColor = System.Drawing.Color.Black;
            this.lblVOClassname.Location = new System.Drawing.Point(16, 58);
            this.lblVOClassname.Name = "lblVOClassname";
            this.lblVOClassname.Size = new System.Drawing.Size(66, 13);
            this.lblVOClassname.TabIndex = 14;
            this.lblVOClassname.Text = "Class Name:";
            // 
            // txtVONamespace
            // 
            this.txtVONamespace.BackColor = System.Drawing.Color.White;
            this.txtVONamespace.ForeColor = System.Drawing.Color.Black;
            this.txtVONamespace.Location = new System.Drawing.Point(81, 25);
            this.txtVONamespace.Name = "txtVONamespace";
            this.txtVONamespace.Size = new System.Drawing.Size(217, 21);
            this.txtVONamespace.TabIndex = 13;
            // 
            // lblVONamespace
            // 
            this.lblVONamespace.AutoSize = true;
            this.lblVONamespace.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVONamespace.ForeColor = System.Drawing.Color.Black;
            this.lblVONamespace.Location = new System.Drawing.Point(16, 29);
            this.lblVONamespace.Name = "lblVONamespace";
            this.lblVONamespace.Size = new System.Drawing.Size(66, 13);
            this.lblVONamespace.TabIndex = 6;
            this.lblVONamespace.Text = "Namespace:";
            // 
            // grpBLLInfo
            // 
            this.grpBLLInfo.Controls.Add(this.txtBLLClassname);
            this.grpBLLInfo.Controls.Add(this.lblBLLClassname);
            this.grpBLLInfo.Controls.Add(this.txtBLLNamespace);
            this.grpBLLInfo.Controls.Add(this.lblBLLNamespace);
            this.grpBLLInfo.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBLLInfo.ForeColor = System.Drawing.Color.Black;
            this.grpBLLInfo.Location = new System.Drawing.Point(332, 105);
            this.grpBLLInfo.Name = "grpBLLInfo";
            this.grpBLLInfo.Size = new System.Drawing.Size(314, 92);
            this.grpBLLInfo.TabIndex = 19;
            this.grpBLLInfo.TabStop = false;
            this.grpBLLInfo.Text = "Business Logic Layer";
            // 
            // txtBLLClassname
            // 
            this.txtBLLClassname.BackColor = System.Drawing.Color.White;
            this.txtBLLClassname.ForeColor = System.Drawing.Color.Black;
            this.txtBLLClassname.Location = new System.Drawing.Point(81, 54);
            this.txtBLLClassname.Name = "txtBLLClassname";
            this.txtBLLClassname.Size = new System.Drawing.Size(217, 21);
            this.txtBLLClassname.TabIndex = 15;
            // 
            // lblBLLClassname
            // 
            this.lblBLLClassname.AutoSize = true;
            this.lblBLLClassname.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBLLClassname.ForeColor = System.Drawing.Color.Black;
            this.lblBLLClassname.Location = new System.Drawing.Point(16, 58);
            this.lblBLLClassname.Name = "lblBLLClassname";
            this.lblBLLClassname.Size = new System.Drawing.Size(66, 13);
            this.lblBLLClassname.TabIndex = 14;
            this.lblBLLClassname.Text = "Class Name:";
            // 
            // txtBLLNamespace
            // 
            this.txtBLLNamespace.BackColor = System.Drawing.Color.White;
            this.txtBLLNamespace.ForeColor = System.Drawing.Color.Black;
            this.txtBLLNamespace.Location = new System.Drawing.Point(81, 25);
            this.txtBLLNamespace.Name = "txtBLLNamespace";
            this.txtBLLNamespace.Size = new System.Drawing.Size(217, 21);
            this.txtBLLNamespace.TabIndex = 13;
            // 
            // lblBLLNamespace
            // 
            this.lblBLLNamespace.AutoSize = true;
            this.lblBLLNamespace.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBLLNamespace.ForeColor = System.Drawing.Color.Black;
            this.lblBLLNamespace.Location = new System.Drawing.Point(16, 29);
            this.lblBLLNamespace.Name = "lblBLLNamespace";
            this.lblBLLNamespace.Size = new System.Drawing.Size(66, 13);
            this.lblBLLNamespace.TabIndex = 6;
            this.lblBLLNamespace.Text = "Namespace:";
            // 
            // grpDALInfo
            // 
            this.grpDALInfo.Controls.Add(this.txtDALClassname);
            this.grpDALInfo.Controls.Add(this.lblDALClassname);
            this.grpDALInfo.Controls.Add(this.txtDALNamespace);
            this.grpDALInfo.Controls.Add(this.lblDALNamespace);
            this.grpDALInfo.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpDALInfo.ForeColor = System.Drawing.Color.Black;
            this.grpDALInfo.Location = new System.Drawing.Point(332, 198);
            this.grpDALInfo.Name = "grpDALInfo";
            this.grpDALInfo.Size = new System.Drawing.Size(314, 92);
            this.grpDALInfo.TabIndex = 20;
            this.grpDALInfo.TabStop = false;
            this.grpDALInfo.Text = "Data Access Layer";
            // 
            // txtDALClassname
            // 
            this.txtDALClassname.BackColor = System.Drawing.Color.White;
            this.txtDALClassname.ForeColor = System.Drawing.Color.Black;
            this.txtDALClassname.Location = new System.Drawing.Point(81, 54);
            this.txtDALClassname.Name = "txtDALClassname";
            this.txtDALClassname.Size = new System.Drawing.Size(217, 21);
            this.txtDALClassname.TabIndex = 15;
            // 
            // lblDALClassname
            // 
            this.lblDALClassname.AutoSize = true;
            this.lblDALClassname.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDALClassname.ForeColor = System.Drawing.Color.Black;
            this.lblDALClassname.Location = new System.Drawing.Point(16, 58);
            this.lblDALClassname.Name = "lblDALClassname";
            this.lblDALClassname.Size = new System.Drawing.Size(66, 13);
            this.lblDALClassname.TabIndex = 14;
            this.lblDALClassname.Text = "Class Name:";
            // 
            // txtDALNamespace
            // 
            this.txtDALNamespace.BackColor = System.Drawing.Color.White;
            this.txtDALNamespace.ForeColor = System.Drawing.Color.Black;
            this.txtDALNamespace.Location = new System.Drawing.Point(81, 25);
            this.txtDALNamespace.Name = "txtDALNamespace";
            this.txtDALNamespace.Size = new System.Drawing.Size(217, 21);
            this.txtDALNamespace.TabIndex = 13;
            // 
            // lblDALNamespace
            // 
            this.lblDALNamespace.AutoSize = true;
            this.lblDALNamespace.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDALNamespace.ForeColor = System.Drawing.Color.Black;
            this.lblDALNamespace.Location = new System.Drawing.Point(16, 29);
            this.lblDALNamespace.Name = "lblDALNamespace";
            this.lblDALNamespace.Size = new System.Drawing.Size(66, 13);
            this.lblDALNamespace.TabIndex = 6;
            this.lblDALNamespace.Text = "Namespace:";
            // 
            // grpLanguageInfo
            // 
            this.grpLanguageInfo.Controls.Add(this.rdoVB);
            this.grpLanguageInfo.Controls.Add(this.rdoCSharp);
            this.grpLanguageInfo.Controls.Add(this.lblLanguage);
            this.grpLanguageInfo.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpLanguageInfo.ForeColor = System.Drawing.Color.Black;
            this.grpLanguageInfo.Location = new System.Drawing.Point(332, 289);
            this.grpLanguageInfo.Name = "grpLanguageInfo";
            this.grpLanguageInfo.Size = new System.Drawing.Size(314, 63);
            this.grpLanguageInfo.TabIndex = 21;
            this.grpLanguageInfo.TabStop = false;
            this.grpLanguageInfo.Text = "Language";
            // 
            // rdoVB
            // 
            this.rdoVB.AutoSize = true;
            this.rdoVB.Location = new System.Drawing.Point(129, 28);
            this.rdoVB.Name = "rdoVB";
            this.rdoVB.Size = new System.Drawing.Size(37, 17);
            this.rdoVB.TabIndex = 16;
            this.rdoVB.Text = "VB";
            this.rdoVB.UseVisualStyleBackColor = true;
            // 
            // rdoCSharp
            // 
            this.rdoCSharp.AutoSize = true;
            this.rdoCSharp.Checked = true;
            this.rdoCSharp.Location = new System.Drawing.Point(81, 28);
            this.rdoCSharp.Name = "rdoCSharp";
            this.rdoCSharp.Size = new System.Drawing.Size(40, 17);
            this.rdoCSharp.TabIndex = 15;
            this.rdoCSharp.TabStop = true;
            this.rdoCSharp.Text = "C#";
            this.rdoCSharp.UseVisualStyleBackColor = true;
            // 
            // lblLanguage
            // 
            this.lblLanguage.AutoSize = true;
            this.lblLanguage.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLanguage.ForeColor = System.Drawing.Color.Black;
            this.lblLanguage.Location = new System.Drawing.Point(16, 30);
            this.lblLanguage.Name = "lblLanguage";
            this.lblLanguage.Size = new System.Drawing.Size(58, 13);
            this.lblLanguage.TabIndex = 14;
            this.lblLanguage.Text = "Language:";
            // 
            // btnClassGenerator
            // 
            this.btnClassGenerator.AutoSize = true;
            this.btnClassGenerator.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClassGenerator.Location = new System.Drawing.Point(517, 443);
            this.btnClassGenerator.Name = "btnClassGenerator";
            this.btnClassGenerator.Size = new System.Drawing.Size(113, 23);
            this.btnClassGenerator.TabIndex = 22;
            this.btnClassGenerator.Text = "Generate Classes...";
            this.btnClassGenerator.UseVisualStyleBackColor = true;
            this.btnClassGenerator.Click += new System.EventHandler(this.btnClassGenerator_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(649, 480);
            this.Controls.Add(this.btnClassGenerator);
            this.Controls.Add(this.grpLanguageInfo);
            this.Controls.Add(this.grpDALInfo);
            this.Controls.Add(this.grpBLLInfo);
            this.Controls.Add(this.grpVOInfo);
            this.Controls.Add(this.grpGenInfo);
            this.Controls.Add(this.grpLocation);
            this.Controls.Add(this.grpDBInfo);
            this.Controls.Add(this.grpServerInfo);
            this.Name = "Form1";
            this.Text = "Form1";
            this.grpServerInfo.ResumeLayout(false);
            this.grpServerInfo.PerformLayout();
            this.grpDBInfo.ResumeLayout(false);
            this.grpDBInfo.PerformLayout();
            this.grpLocation.ResumeLayout(false);
            this.grpLocation.PerformLayout();
            this.grpGenInfo.ResumeLayout(false);
            this.grpGenInfo.PerformLayout();
            this.grpVOInfo.ResumeLayout(false);
            this.grpVOInfo.PerformLayout();
            this.grpBLLInfo.ResumeLayout(false);
            this.grpBLLInfo.PerformLayout();
            this.grpDALInfo.ResumeLayout(false);
            this.grpDALInfo.PerformLayout();
            this.grpLanguageInfo.ResumeLayout(false);
            this.grpLanguageInfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpServerInfo;
        private System.Windows.Forms.CheckBox chkIsWindowsAuth;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtServerName;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label lblServer;
        private System.Windows.Forms.GroupBox grpDBInfo;
        private System.Windows.Forms.Label lblPKValue;
        private System.Windows.Forms.Label lblPK;
        private System.Windows.Forms.ComboBox cmbDatabases;
        private System.Windows.Forms.ComboBox cmbTables;
        private System.Windows.Forms.Label lblTables;
        private System.Windows.Forms.Label lblDatabases;
        private System.Windows.Forms.GroupBox grpLocation;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.TextBox txtLocation;
        private System.Windows.Forms.Label lblLocation;
        private System.Windows.Forms.FolderBrowserDialog fldBrowseDialog;
        private System.Windows.Forms.Label lblGenInfo;
        private System.Windows.Forms.GroupBox grpGenInfo;
        private System.Windows.Forms.TextBox txtVOClassname;
        private System.Windows.Forms.GroupBox grpVOInfo;
        private System.Windows.Forms.Label lblVOClassname;
        private System.Windows.Forms.TextBox txtVONamespace;
        private System.Windows.Forms.Label lblVONamespace;
        private System.Windows.Forms.GroupBox grpBLLInfo;
        private System.Windows.Forms.TextBox txtBLLClassname;
        private System.Windows.Forms.Label lblBLLClassname;
        private System.Windows.Forms.TextBox txtBLLNamespace;
        private System.Windows.Forms.Label lblBLLNamespace;
        private System.Windows.Forms.GroupBox grpDALInfo;
        private System.Windows.Forms.TextBox txtDALClassname;
        private System.Windows.Forms.Label lblDALClassname;
        private System.Windows.Forms.TextBox txtDALNamespace;
        private System.Windows.Forms.Label lblDALNamespace;
        private System.Windows.Forms.GroupBox grpLanguageInfo;
        private System.Windows.Forms.RadioButton rdoVB;
        private System.Windows.Forms.RadioButton rdoCSharp;
        private System.Windows.Forms.Label lblLanguage;
        private System.Windows.Forms.Button btnClassGenerator;
    }
}

